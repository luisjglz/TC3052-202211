import './App.css';
import Header from './components/Header'
import CardsPage from './components/CardsPage';
import Footer from './components/Footer';

function App() {
  return (
    <div className="App">
      <Header/>
      <CardsPage/>
      <Footer/>
    </div>
  );
}

export default App;
