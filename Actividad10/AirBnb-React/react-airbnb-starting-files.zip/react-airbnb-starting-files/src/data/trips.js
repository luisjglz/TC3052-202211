const trips = [
    {
        title: "Plan The Perfect Mexico Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
    {
        title: "Plan The Perfect New York Vacation",
        rating: 4.98,
        reviews: 130,
        country:"United States",
        startPrice: 102
    },
]

export default trips;