import React from 'react'
import world from '../img/world.svg'

export default function Bottom() {
    return (
        <div className="footer-bottom">
            <p>© 2022 Airbnb, Inc. · Privacy · Terms · Sitemap</p>
            <p><img src={world} className='world' alt="World"/>English (US) Choose a currency $MXN </p>
        </div>
    )
}
