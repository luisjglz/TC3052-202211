import React from 'react'
import heart from '../img/heart.svg'
import star from '../img/star.svg'

export default function Card(props) {

  const { id, trip } = props;

  return (
    <div className="card">
      <img src={`https://picsum.photos/240/340?r=${id}`} className="card-image" alt="Destination"/>
      <img src={heart} className="like" alt="Heart icon"/>
      <img src={star} className="star" alt="Star icon"/><span className="rating">{trip.rating}</span><span className="reviews">({trip.reviews})</span><span className="country">· {trip.country}</span>
      <p className="place">{trip.title}</p>
      <p className="price">From ${trip.startPrice} MXN / <span>person</span></p>
    </div>
  )
}
