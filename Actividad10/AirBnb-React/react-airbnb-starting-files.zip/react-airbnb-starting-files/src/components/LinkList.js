import React from 'react'

export default function LinkList(props) {

    const {list} = props;
    
  return (
    <ul>
        {list.map((l,i) => (
            <li key={i}>{l}</li>
        ))}
    </ul>
  )
}
