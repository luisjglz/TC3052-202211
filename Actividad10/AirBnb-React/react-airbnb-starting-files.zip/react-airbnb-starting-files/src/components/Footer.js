import React from 'react'
import LinkList from './LinkList.js'
import Bottom from './Bottom.js'

export default function Footer() {

    const support = [
        'Support',
        'Help Center',
        'AirCover',
        'Safety information',
        'Supporting people with disabilities',
        'Cancellation options',
        'Our COVID-19 Response',
        'Report a neighborhood concern',
    ]

    const community = [
        'Community',
        'Airbnb.org: disaster relief housing',
        'Support Afghan refugees',
        'Combating discrimination',
    ]

    const hosting = [
        'Hosting',
        'Try hosting',
        'AirCover for Hosts',
        'Explore hosting resources',
        'Visit our community forum',
        'How to host responsibly',
    ]

    const about = [
        'About',
        'Newsroom',
        'Learn about new features',
        'Letter from our founders',
        'Careers',
        'Investors',
    ]

    return (
        <footer>
            <div className="footer-menu">
                <LinkList list={support} />
                <LinkList list={community} />
                <LinkList list={hosting} />
                <LinkList list={about} />
            </div>
            <Bottom />
        </footer>
    )
}
