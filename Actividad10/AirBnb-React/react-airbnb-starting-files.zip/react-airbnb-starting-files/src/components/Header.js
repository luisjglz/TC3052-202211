import React from 'react'
import logo from '../img/aribnb-logo.png'
import world from '../img/world.svg'
import menu from '../img/menu.svg'

export default function Header() {
  return (
    <header>
        <a href="#."><img src={logo} className='airbnb-logo' alt="Airbnb logo"/></a>
        <nav>
            <h1>Become a Host</h1>
            <img src={world} alt="World"/>
            <div className="user">
                <img src={menu} className="menu" alt="Menu"/>
                <img src="https://picsum.photos/200" className="user-pic" alt="User"/>
            </div>
        </nav>
    </header>
  )
}
