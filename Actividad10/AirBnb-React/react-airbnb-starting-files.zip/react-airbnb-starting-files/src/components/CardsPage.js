import React from 'react'

import trips from '../data/trips'
import Card from './Card'

export default function CardsPage() {

  return (
    <section className="cards">
        <h1>Plan a trip with help from local Hosts around the world</h1>
        <div className="cards-container">
            {trips.map((t,i)=> (
                <Card key={i} id={i+1} trip={t}/>
            ))}
        </div>
    </section>
  )
}
