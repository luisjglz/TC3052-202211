const Bicicleta = require('../../models/bicicleta')
const request = require('request')

describe('Bicicletas API', () => {
    describe('GET BICILETAS /', () => {
        it('Status code 200', () =>{
            expect(Bicicleta.allBicis.length).toBe(0)
            let b = new Bicicleta(3, 'blanca', 'Benotto', [19.283, -99.133])
            Bicicleta.add(b)
            request.get('http://localhost:3000/api/bicicletas/', (error, response, body) => {
                expect(response.statusCode).toBe(200)
            })
        
        })
    })
})
