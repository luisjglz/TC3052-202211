const Bicicleta = require('../models/bicicleta')

beforeEach( () => {
    Bicicleta.allBicis = []
})

describe('Bicis DB', () => {
    it('Debería iniciar vacía', () => {
        expect(Bicicleta.allBicis.length).toBe(0)
    })
})

describe('Add a bike', () => {
    it('should add a bike', () => {
        expect(Bicicleta.allBicis.length).toBe(0)
        let b = new Bicicleta(3, 'blanca', 'Benotto', [19.283, -99.133])
        Bicicleta.add(b)
        expect(Bicicleta.allBicis.length).toBe(1)

    })
})

describe('Find a bike', () => {
    it('should find a bike', () => {
        expect(Bicicleta.allBicis.length).toBe(0)
        let b = new Bicicleta(3, 'blanca', 'Benotto', [19.283, -99.133])
        Bicicleta.add(b)
        let b2 = Bicicleta.findById(3)
        expect(b2.modelo).toBe("Benotto")
    })
})

describe('Remove a bike', () => {
    it('should remove a bike', () => {
        expect(Bicicleta.allBicis.length).toBe(0)
        let b = new Bicicleta(3, 'blanca', 'Benotto', [19.283, -99.133])
        Bicicleta.add(b)
        expect(Bicicleta.allBicis.length).toBe(1)
        Bicicleta.removeById(3)
        expect(Bicicleta.allBicis.length).toBe(0)
    })
})