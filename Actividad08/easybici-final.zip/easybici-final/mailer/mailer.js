const nodemailer = require('nodemailer')

const mailConfig = {
    host: 'smtp.ethereal.email',
    port: 587,
    auth: {
        user: 'norene.schulist9@ethereal.email',
        pass: 'sWDYJZAaf5BJn9KaW6'
    }
}

module.exports = nodemailer.createTransport(mailConfig)
